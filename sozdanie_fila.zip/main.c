#include <stdio.h>
  
int main(void)
{
    char * message = "Строка для записи в файл" ;
    char * filename = "data.txt";
    FILE *fp = fopen(filename, "w");
    if(fp)
    {
        fputs(message, fp);
        fclose(fp);
        printf("File has been written\n");
    }
}